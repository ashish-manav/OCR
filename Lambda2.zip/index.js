let AWS = require('aws-sdk');
const AWSJsonParser = require('aws-textract-json-parser');

const s3 = new AWS.S3();
const textract = new AWS.Textract();


exports.handler = function(event, context, callback) {
    console.log('Lambda 2 SNS handler');
    console.log('event details');
    console.log(event);
    console.log(event.Records[0]);
    console.log(event.Records[0].Sns);
    console.log(event.Records[0].Sns.Message);
    var message = event.Records[0].Sns.Message;
    var msgBody = JSON.parse(event.Records[0].Sns.Message);
    console.log('Message received from SNS:', msgBody);

    var JobId = msgBody.JobId;
    var filename  = msgBody.DocumentLocation.S3ObjectName;
    filename = filename.split('.')[0] + '.txt';
    console.log('JobId is::');
    console.log(JobId);

    var params = {
        JobId: JobId /* required */
        //MaxResults: 'NUMBER_VALUE',
        //NextToken: 'STRING_VALUE'
    };
    textract.getDocumentAnalysis(params, function(err, returnData) {
        console.log('function successfully called');
        if (err) console.log(err, err.stack); // an error occurred
        else {
            //console.log(data);           // successful response

            let forUpload = '';
            /*
                       console.log(returnData.Blocks.length);
                       for(var index=0;index<returnData.Blocks.length;index++){
                            if(returnData.Blocks[index].BlockType == 'KEY_VALUE_SET'){
                                console.log(returnData.Blocks[index]);
                                //console.log(returnData.Blocks[index].Text);
                                console.log(returnData.Blocks[index].Relationships);
                                //forUpload = forUpload + '  ' + returnData.Blocks[index].Text;
                            }
                        }
                        
                        */
            const res = AWSJsonParser(returnData);

            // Call one of 3 functions getTableData, getFormData, getRawData
            // Optional object to specify the confidence level, default is 0

            // Example of getting the table data.
            const tableData = res.getTableData({
                minConfidence: 50
            });
            // Example of getting the form data.
            const formData = res.getFormData();
            // Example of getting the raw(line) data.
            const rawData = res.getRawData();

            console.log(tableData);
            console.log(formData);
            let completeDate = {
                'tableData' : tableData,
                'formData' : formData,
                'rawData' : rawData
            };
            
            

            //console.log(forUpload);

            var params2 = {
                Bucket: "textract-console-us-east-1-fd66c885-984d-4df2-9c0f-0f1ff0d0326a", // name of dest bucket
                Key: filename,
                Body: JSON.stringify(completeDate) //'test string'//data
            };
            s3.upload(params2, function(err, data) {
                if (err) console.log(err, err.stack);
                else console.log(data);
            });

        }
    });callback(null, {"message": "Successfully executed"});
}